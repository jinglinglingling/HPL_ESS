import math
import os
import random
from copy import deepcopy

import mmcv
import numpy as np
import torch
from matplotlib import pyplot as plt
from timm.models.layers import DropPath
from torch.nn.modules.dropout import _DropoutNd

from mmseg.core import add_prefix
from mmseg.models import UDA, build_segmentor
from mmseg.models.uda.uda_decorator import UDADecorator, get_module
from mmseg.models.utils.dacs_transforms import (denorm, get_class_masks,
                                                get_mean_std, strong_transform)
from mmseg.models.utils.visualization import subplotimg
from mmseg.utils.utils import downscale_label_ratio
import torch.nn as nn
import torch.nn.functional as F
import objax

def _params_equal(ema_model, model):
    for ema_param, param in zip(ema_model.named_parameters(),
                                model.named_parameters()):
        if not torch.equal(ema_param[1].data, param[1].data):
            # print("Difference in", ema_param[0])
            return False
    return True


def calc_grad_magnitude(grads, norm_type=2.0):
    norm_type = float(norm_type)
    if norm_type == math.inf:
        norm = max(p.abs().max() for p in grads)
    else:
        norm = torch.norm(
            torch.stack([torch.norm(p, norm_type) for p in grads]), norm_type)

    return norm


@UDA.register_module()
class DACS(UDADecorator):
    def __init__(self, **cfg):
        super(DACS, self).__init__(**cfg)
        self.local_iter = 0
        self.max_iters = cfg['max_iters']
        self.alpha = cfg['alpha']
        self.pseudo_threshold = cfg['pseudo_threshold']
        self.psweight_ignore_top = cfg['pseudo_weight_ignore_top']
        self.psweight_ignore_bottom = cfg['pseudo_weight_ignore_bottom']
        self.fdist_lambda = cfg['imnet_feature_dist_lambda']
        self.fdist_classes = cfg['imnet_feature_dist_classes']
        self.fdist_scale_min_ratio = cfg['imnet_feature_dist_scale_min_ratio']
        self.enable_fdist = self.fdist_lambda > 0
        self.mix = cfg['mix']
        self.blur = cfg['blur']
        self.color_jitter_s = cfg['color_jitter_strength']
        self.color_jitter_p = cfg['color_jitter_probability']
        self.debug_img_interval = cfg['debug_img_interval']
        self.print_grad_magnitude = cfg['print_grad_magnitude']
        assert self.mix == 'class'

        self.debug_fdist_mask = None
        self.debug_gt_rescale = None

        self.class_probs = {}
        ema_cfg = deepcopy(cfg['model'])
        self.ema_model = build_segmentor(ema_cfg)

        if self.enable_fdist:
            self.imnet_model = build_segmentor(deepcopy(cfg['model']))
        else:
            self.imnet_model = None

        self.pos_embedding = nn.Conv2d(in_channels=9, out_channels=3, kernel_size=1, stride=1, padding=0, bias=True)

        self.e2vid = True
        self.iternumber = 0

        self.p_labeled = objax.nn.ExponentialMovingAverage((11,), init_value=1 / 11)
        self.p_labeled2 = objax.nn.ExponentialMovingAverage((11,), init_value=1 / 11)
        self.p_unlabeled = objax.nn.MovingAverage((11,), buffer_size=512, init_value=1 / 11)

    def get_ema_model(self):
        return get_module(self.ema_model)

    def get_imnet_model(self):
        return get_module(self.imnet_model)

    def _init_ema_weights(self):
        for param in self.get_ema_model().parameters():
            param.detach_()
        mp = list(self.get_model().parameters())
        mcp = list(self.get_ema_model().parameters())
        for i in range(0, len(mp)):
            if not mcp[i].data.shape:  # scalar tensor
                mcp[i].data = mp[i].data.clone()
            else:
                mcp[i].data[:] = mp[i].data[:].clone()

    def _update_ema(self, iter):
        alpha_teacher = min(1 - 1 / (iter + 1), self.alpha)
        for ema_param, param in zip(self.get_ema_model().parameters(),
                                    self.get_model().parameters()):
            if not param.data.shape:  # scalar tensor
                ema_param.data = \
                    alpha_teacher * ema_param.data + \
                    (1 - alpha_teacher) * param.data
            else:
                ema_param.data[:] = \
                    alpha_teacher * ema_param[:].data[:] + \
                    (1 - alpha_teacher) * param[:].data[:]

    def train_step(self, data_batch, optimizer, **kwargs):
        optimizer.zero_grad()
        log_vars = self(**data_batch)
        optimizer.step()

        log_vars.pop('loss', None)  # remove the unnecessary 'loss'
        outputs = dict(
            log_vars=log_vars, num_samples=len(data_batch['img_metas']))
        return outputs

    def masked_feat_dist(self, f1, f2, mask=None):
        feat_diff = f1 - f2
        pw_feat_dist = torch.norm(feat_diff, dim=1, p=2)

        if mask is not None:
            pw_feat_dist = pw_feat_dist[mask.squeeze(1)]
        return torch.mean(pw_feat_dist)

    def calc_feat_dist(self, img, gt, feat=None):
        assert self.enable_fdist
        with torch.no_grad():
            self.get_imnet_model().eval()
            feat_imnet = self.get_imnet_model().extract_feat(img)
            feat_imnet = [f.detach() for f in feat_imnet]
        lay = -1

        if self.fdist_classes is not None:
            fdclasses = torch.tensor(self.fdist_classes, device=gt.device)
            scale_factor = gt.shape[-1] // feat[lay].shape[-1]
            gt_rescaled = downscale_label_ratio(gt, scale_factor,
                                                self.fdist_scale_min_ratio,
                                                self.num_classes,
                                                255).long().detach()
            fdist_mask = torch.any(gt_rescaled[..., None] == fdclasses, -1)
            feat_dist = self.masked_feat_dist(feat[lay], feat_imnet[lay],
                                              fdist_mask)
            self.debug_fdist_mask = fdist_mask
            self.debug_gt_rescale = gt_rescaled
        else:
            feat_dist = self.masked_feat_dist(feat[lay], feat_imnet[lay])
        feat_dist = self.fdist_lambda * feat_dist
        feat_loss, feat_log = self._parse_losses(
            {'loss_imnet_feat_dist': feat_dist})
        feat_log.pop('loss', None)
        return feat_loss, feat_log

    def forward_train(self, img, img_metas, gt_semantic_seg, target_label_img,
                      target_label_img_metas, target_gt, target_unlabel_img,
                      target_unlabel_img_metas):
        log_vars = {}
        batch_size = img.shape[0]
        dev = img.device

        target_img = target_unlabel_img
        target_img_metas = target_unlabel_img_metas

        # Init/update ema model
        if self.local_iter == 0:
            self._init_ema_weights()

        if self.local_iter > 0:
            self._update_ema(self.local_iter)

        means, stds = get_mean_std(img_metas, dev)
        strong_parameters = {
            'mix': None,
            'color_jitter': random.uniform(0, 1),
            'color_jitter_s': self.color_jitter_s,
            'color_jitter_p': self.color_jitter_p,
            'blur': random.uniform(0, 1) if self.blur else 0,
            'mean': means[0].unsqueeze(0),
            'std': stds[0].unsqueeze(0)
        }


        # Train on source images
        clean_losses = self.get_model().forward_train(
            img, img_metas, gt_semantic_seg, return_feat=True,soft_label=True)
        src_feat = clean_losses.pop('features')
        clean_loss, clean_log_vars = self._parse_losses(clean_losses)
        log_vars.update(clean_log_vars)
        clean_loss.backward(retain_graph=self.enable_fdist)
        if self.print_grad_magnitude:
            params = self.get_model().backbone.parameters()
            seg_grads = [
                p.grad.detach().clone() for p in params if p.grad is not None
            ]
            grad_mag = calc_grad_magnitude(seg_grads)
            mmcv.print_log(f'Seg. Grad.: {grad_mag}', 'mmseg')

        
        # ImageNet feature distance
        # if self.enable_fdist:
        #     feat_loss, feat_log = self.calc_feat_dist(img, gt_semantic_seg,
        #                                               src_feat)
        #     feat_loss.backward()
        #     log_vars.update(add_prefix(feat_log, 'src'))
        #     if self.print_grad_magnitude:
        #         params = self.get_model().backbone.parameters()
        #         fd_grads = [
        #             p.grad.detach() for p in params if p.grad is not None
        #         ]
        #         fd_grads = [g2 - g1 for g1, g2 in zip(seg_grads, fd_grads)]
        #         grad_mag = calc_grad_magnitude(fd_grads)
        #         mmcv.print_log(f'Fdist Grad.: {grad_mag}', 'mmseg')
        

        # Generate teacher net pseudo-label
        for m in self.get_ema_model().modules():
            if isinstance(m, _DropoutNd):
                m.training = False
            if isinstance(m, DropPath):
                m.training = False
        ema_logits = self.get_ema_model().encode_decode(
            target_img, target_img_metas)
        ema_softmax = torch.softmax(ema_logits.detach(), dim=1)
        
        pseudo_prob, pseudo_label = torch.max(ema_softmax, dim=1)
        ps_large_p = pseudo_prob.ge(self.pseudo_threshold).long() == 1
        ps_size = np.size(np.array(pseudo_label.cpu()))
        pseudo_weight = torch.sum(ps_large_p).item() / ps_size
        pseudo_weight = pseudo_weight * torch.ones(
            pseudo_prob.shape, device=dev)
        
        # # generate 255 masked pseudo label
        ema_label_logits = self.get_ema_model().encode_decode(
        target_label_img, target_label_img_metas)
        ema_label_softmax = torch.softmax(ema_label_logits.detach(), dim=1)
        pseudo_label_prob, pseudo_label_label = torch.max(ema_label_softmax, dim=1)
        pseudo_label_label = pseudo_label_label.reshape((2,1,460,640))
        # idx = torch.where(target_gt==255)
        # target_gt[idx] = pseudo_label_label[idx]

        if self.e2vid:
            E2vid_gray = target_gt
            if self.iternumber > 5000:
                # Generate E2vid as target GT
                with torch.no_grad():
                    for m in self.get_model().modules():
                        if isinstance(m, _DropoutNd):
                            m.training = False
                        if isinstance(m, DropPath):
                            m.training = False
                    target_gt_logits = self.get_model().encode_decode(
                        target_gt, target_img_metas)
                    target_gt_softmax = torch.softmax(target_gt_logits.detach(), dim=1)
                    target_gt_prob, target_gt = torch.max(target_gt_softmax, dim=1)
                    target_gtpseudo_weight = torch.sum(ps_large_p).item() / ps_size
                    target_gtpseudo_weight = target_gtpseudo_weight * torch.ones(
                        pseudo_prob.shape, device=dev)
                    for m in self.get_model().modules():
                        if isinstance(m, _DropoutNd):
                            m.training = True
                        if isinstance(m, DropPath):
                            m.training = True
                    target_gt = target_gt.unsqueeze(1)

                    # target_gt_proto = target_gt_logits.cpu().detach().numpy()
                    target_gt_proto = target_gt_softmax.cpu().detach().numpy()
                    target_gt_proto = target_gt_proto.mean(0).mean(1).mean(1)
                    target_gt_proto = self.p_labeled(target_gt_proto)

            else:
                idx = torch.where(target_gt==255)
                target_gt[idx] = pseudo_label_label[idx]
                

#############consist_evid

        if self.iternumber > 5000:

            scale = torch.from_numpy(np.asarray(target_gt_proto))
            scale = scale.reshape((1,11,1,1)).cuda()

            target1 = F.softmax(ema_label_logits - scale,dim=1)
            target2 = F.softmax(target_gt_logits - scale,dim=1)


            m = 0.5 * (target1 + target2)
            kl_pm = F.kl_div(torch.log(target1), m, reduction='none')
            kl_qm = F.kl_div(torch.log(target2), m, reduction='none')
            js_div = 0.5 * (kl_pm + kl_qm)


            # teacher = F.softmax(target1,dim=1)
            # student = F.log_softmax(target2,dim=1)
            # loss_consist_t = F.kl_div(student, teacher, reduction='none')
            
            loss_consist_t = torch.mean(torch.sum(js_div, dim=1))


            loss_consist_t.requires_grad_()
            kl_losses_t = loss_consist_t
            kl_losses_t.backward()
############# 
           
#############consist source
        source_feature = clean_losses['decode.fea']
        # source_proto = source_feature
        source_proto = F.softmax(source_feature,dim=1)
        source_proto = source_proto.cpu().detach().numpy()
        source_proto = source_proto.mean(0).mean(1).mean(1)
        source_proto = self.p_labeled(source_proto)
        # kl_losses = dict()
        # kl_loss_v2=torch.nn.KLDivLoss(reduction = 'batchmean')
        if self.iternumber > 5000:
            scale = torch.from_numpy(np.asarray(source_proto))
            scale = scale.reshape((1,11,1,1)).cuda()


            # target1 = torch.norm(ema_label_logits - scale, 2, dim=1,)
            # target2 = torch.norm(target_gt_logits - scale, 2, dim=1,)

            target1 = F.softmax(ema_label_logits - scale,dim=1)
            target2 = F.softmax(target_gt_logits - scale,dim=1)

            m = 0.5 * (target1 + target2)
            kl_pm = F.kl_div(torch.log(target1), m, reduction='none')
            kl_qm = F.kl_div(torch.log(target2), m, reduction='none')
            js_div = 0.5 * (kl_pm + kl_qm)

            # teacher = F.softmax(target1,dim=1)
            # student = F.log_softmax(target2,dim=1)
            # loss_consist = F.kl_div(student, teacher, reduction='none')
            
            loss_consist = torch.mean(torch.sum(js_div, dim=1))


            loss_consist.requires_grad_()
            kl_losses = loss_consist
            kl_losses.backward()

############


        if self.psweight_ignore_top > 0:
            pseudo_weight[:, :self.psweight_ignore_top, :] = 0
        if self.psweight_ignore_bottom > 0:
            pseudo_weight[:, -self.psweight_ignore_bottom:, :] = 0
        gt_pixel_weight = torch.ones((pseudo_weight.shape), device=dev)


        # Apply mixing
        mixed_img, mixed_lbl = [None] * batch_size, [None] * batch_size
        mix_masks = get_class_masks(gt_semantic_seg)


        #####all
        # target_img = target_label_img
        # pseudo_label = target_gt
        ######
        for i in range(batch_size):
            strong_parameters['mix'] = mix_masks[i]
            mixed_img[i], mixed_lbl[i] = strong_transform(
                strong_parameters,
                data=torch.stack((img[i], target_img[i])),
                target=torch.stack((gt_semantic_seg[i][0], pseudo_label[i])))   # 这里改成和cotrain-label 去mix
            _,  pseudo_weight[i] = strong_transform(
                strong_parameters,
                target=torch.stack((gt_pixel_weight[i], pseudo_weight[i])))
        mixed_img = torch.cat(mixed_img)
        mixed_lbl = torch.cat(mixed_lbl)



        mixed_img_event, mixed_lbl_event = [None] * batch_size, [None] * batch_size
        mix_masks_event = get_class_masks(target_gt)
        for i in range(batch_size):
            strong_parameters['mix'] = mix_masks_event[i]
            mixed_img_event[i], mixed_lbl_event[i] = strong_transform(
                strong_parameters,
                data=torch.stack((target_label_img[i], target_img[i])),
                target=torch.stack((target_gt[i], pseudo_label[i].unsqueeze(0))))
            _, pseudo_weight[i] = strong_transform(
                strong_parameters,
                target=torch.stack((gt_pixel_weight[i], pseudo_weight[i])))
        mixed_img_event = torch.cat(mixed_img_event)
        mixed_lbl_event = torch.cat(mixed_lbl_event)

        # Train on mixed images
        if self.e2vid:
            if self.iternumber > 5000:
                mix_losses = self.get_model().forward_train(
                    mixed_img, img_metas, mixed_lbl, return_feat=True)
                mix_losses.pop('features')
                mix_losses = add_prefix(mix_losses, 'img_unlabel')
                mix_loss, mix_log_vars = self._parse_losses(mix_losses)
                log_vars.update(mix_log_vars)
                mix_loss.backward()

                mix_losses_event = self.get_model().forward_train(
                    mixed_img_event, target_img_metas, mixed_lbl_event, return_feat=True)
                mix_losses_event.pop('features')
                mix_losses_event = add_prefix(mix_losses_event, 'label_unlabel')
                mix_losses_event, mix_log_vars_event = self._parse_losses(mix_losses_event)
                log_vars.update(mix_log_vars_event)
                mix_losses_event.backward()
                
                # self.iternumber += 1
        else:

            mix_losses = self.get_model().forward_train(
                mixed_img, img_metas, mixed_lbl, return_feat=True)
            mix_losses.pop('features')
            mix_losses = add_prefix(mix_losses, 'img_unlabel')
            mix_loss, mix_log_vars = self._parse_losses(mix_losses)
            log_vars.update(mix_log_vars)
            mix_loss.backward()


            mix_losses_event = self.get_model().forward_train(
                mixed_img_event, target_img_metas, mixed_lbl_event, return_feat=True)
            mix_losses_event.pop('features')
            mix_losses_event = add_prefix(mix_losses_event, 'label_unlabel')
            mix_losses_event, mix_log_vars_event = self._parse_losses(mix_losses_event)
            log_vars.update(mix_log_vars_event)
            mix_losses_event.backward()


        self.iternumber += 1

        if self.local_iter % self.debug_img_interval == 0:
            out_dir = os.path.join(self.train_cfg['work_dir'],
                                   'class_mix_debug')
            os.makedirs(out_dir, exist_ok=True)

            for j in range(batch_size):
                rows, cols = 3, 3
                fig, axs = plt.subplots(
                    rows,
                    cols,
                    figsize=(3 * cols, 3 * rows),
                    gridspec_kw={
                        'hspace': 0.1,
                        'wspace': 0,
                        'top': 0.95,
                        'bottom': 0,
                        'right': 1,
                        'left': 0
                    },
                )

                def trans_img(img):
                    img = img.sum(dim=0)
                    if img.min() < 0:
                        img = img - img.min()
                    img = img / (img.max() - img.min()) * 255
                    return img.type(torch.uint8)

                def trans_event(event):  
                    event = event.sum(dim=0)
                    event_r = torch.zeros(event.shape)
                    event_g = torch.zeros(event.shape)
                    event_b = torch.zeros(event.shape)
                    event_r[event > 0] = 255
                    event_g[event < 0] = 255
                    return torch.stack((event_r, event_g, event_b)).type(torch.uint8)

               # Visualize train
                subplotimg(
                    axs[0][0],
                    img[j],
                    'Source Image',
                    cmap='gray')
                subplotimg(
                    axs[0][1],
                    gt_semantic_seg[j],
                    'Source GT',
                    cmap='cityscapes')
                subplotimg(
                    axs[1][0], 
                    trans_event(target_unlabel_img[j]), 
                    'Target unlabel', 
                    cmap='gray')
                subplotimg(
                    axs[1][1],
                    pseudo_label[j],
                    'Pseudo label',
                    cmap='cityscapes')
                # subplotimg(
                #     axs[1][2],
                #     target_unlabel_gt[j],
                #     'target unlabel gt',
                #     cmap='cityscapes')
                subplotimg(
                    axs[2][0],
                    trans_event(target_label_img[j]),
                    'Target labeled')
                if self.e2vid:
                    subplotimg(
                        axs[2][1],
                        E2vid_gray[j],
                        'E2vid gray',
                        cmap='gray')
                subplotimg(
                    axs[2][2], 
                    target_gt[j], 
                    'E2vid gray label', 
                    cmap='cityscapes')
                    
                for ax in axs.flat:
                    ax.axis('off')
                plt.savefig(
                    os.path.join(out_dir,
                                 f'{(self.local_iter + 1):06d}_{j}.png'))
                plt.close()
        self.local_iter += 1
        return log_vars
